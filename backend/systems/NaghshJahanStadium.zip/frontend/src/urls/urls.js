

export const LocalUrl = "http://localhost:8000/"