PROJECT_NAME="NaghshJahanStadium"
EMAIL="paneltesting021@gmail.com"
USERNAME="paneltesting021@gmail.com"
PASSWORD="gaiwtczxpjibdttk"
