PROJECT_NAME="test"
EMAIL="asdfa@gmail.com"
USERNAME="asdfa@gmail.com"
PASSWORD="sdfasdfasdf"
