PROJECT_NAME="DrBahmanZamani"
EMAIL = 'test'
USERNAME = 'test'
PASSWORD = 'test'