PROJECT_NAME="DrBahmanZamaniBooking"
EMAIL = 'test'
USERNAME = 'test'
PASSWORD = 'test'